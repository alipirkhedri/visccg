## ValidMYCard---Credit-Card-Generator-Validiator
 Simple Credit Card Generator and Validiator based on HTML,Javascript and Jquery
 
 ## Screenshot
 ![alt text](https://i.imgur.com/l6scahw.png)
 
 ## Credits
 > Credit card validator
